Execute the DDL scripts in this directory.
